// Рисовалка

package paint;


import paint.Painting;

public class Runner {
    public static void main(String[] args) {
		Painting my=new Painting();
		my.setVisible(true);
	}
    
}
