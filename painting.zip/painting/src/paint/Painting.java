
package paint;

import paint.MyPoint;
import java.awt.Frame;
import java.awt.Graphics;
import java.awt.Menu;
import java.awt.MenuBar;
import java.awt.MenuItem;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionAdapter;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.util.Vector;

import java.awt.Color;
import java.awt.Point;

class Painting extends Frame {

private MenuBar m = new MenuBar();
private Menu m1 = new Menu("Colors");
private Menu m2 = new Menu("Thickness");
private MenuItem mi11 = new MenuItem("Red");
private MenuItem mi12 = new MenuItem("Green");
private MenuItem mi13 = new MenuItem("Blue");
private MenuItem mi21 = new MenuItem("5");
private MenuItem mi22 = new MenuItem("10");
private MenuItem mi23 = new MenuItem("15");
int oldX;
int oldY;

Vector<Vector<MyPoint>> vec = new Vector<Vector<MyPoint>>();

private Color c = new Color(0, 0, 0);
private int n = 5;

public Painting() {
this.setTitle("Painting");
this.setSize(800, 800);
this.setLocation(100, 100);

this.addWindowListener(new WindowListener() {

public void windowOpened(WindowEvent arg0) {
// TODO Auto-generated method stub
}

public void windowIconified(WindowEvent arg0) {
// TODO Auto-generated method stub
}

public void windowDeiconified(WindowEvent arg0) {
// TODO Auto-generated method stub
}

public void windowDeactivated(WindowEvent arg0) {
// TODO Auto-generated method stub
}

public void windowClosing(WindowEvent arg0) {
	dispose();
	System.exit(0);
}

public void windowClosed(WindowEvent arg0) {
	dispose();
	System.exit(0);
}

public void windowActivated(WindowEvent arg0) {
// TODO Auto-generated method stub
}
});

m.add(m1);
m.add(m2);

m1.add(mi11);
m1.add(mi12);
m1.add(mi13);

m2.add(mi21);
m2.add(mi22);
m2.add(mi23);

this.setMenuBar(m);

this.setVisible(true);


mi11.addActionListener(new ActionListener() {
	public void actionPerformed(ActionEvent e) {
	System.out.println("Выбран красный цвет");
	c = Color.RED;
	}
	});

	mi12.addActionListener(new ActionListener() {
	public void actionPerformed(ActionEvent e) {
	System.out.println("Выбран зелёный цвет");
	c = Color.GREEN;
	}
	});

	mi13.addActionListener(new ActionListener() {
	public void actionPerformed(ActionEvent e) {
	System.out.println("Выбран голубой цвет");
	c = Color.BLUE;
	}
	});

	mi21.addActionListener(new ActionListener() {
	public void actionPerformed(ActionEvent e) {
	System.out.println("выбрана толщина 5");
	n = 5;

	}
	});

	mi22.addActionListener(new ActionListener() {
	public void actionPerformed(ActionEvent e) {
	System.out.println("выбрана толщина 10");
	n = 10;

	}
	});

	mi23.addActionListener(new ActionListener() {
	public void actionPerformed(ActionEvent e) {
	System.out.println("выбрана толщина 15");
	n = 15;

	}
	});

	addMouseListener(new MouseAdapter(){
	public void mousePressed(MouseEvent e) {
	System.out.println("Нажатие состоялось!");

	Graphics g = getGraphics();
	
	g.setColor(c);

	oldX = e.getX();
	oldY = e.getY();

	g.fillOval(oldX, oldY, n, n);

	vec.add(new Vector<MyPoint>());
	vec.get(vec.size() - 1).add(new MyPoint(e.getX(), e.getY(), n, c));
	}
	});

	addMouseMotionListener(new MouseMotionAdapter(){
	public void mouseDragged(MouseEvent e) {
	Graphics g = getGraphics();

	g.setColor(c);
	oldX = e.getX();
	oldY = e.getY();

	g.fillOval(oldX, oldY, n, n);

	vec.get(vec.size() - 1).add(new MyPoint(e.getX(), e.getY(), n, c));
	}
	});
	}

	public void paint(Graphics g) {
	for (int i = 0; i < vec.size(); i++) {
	//System.out.println(" " + i);
	g.setColor(vec.get(i).get(0).getColor());
	for (int j = 0; j < vec.get(i).size(); j++) {
	g.fillOval((int) (vec.get(i).get(j).getX()),(int) (vec.get(i).get(j).getY()), (int) (vec.get(i).get(j).getDepth()), (int) (vec.get(i).get(j).getDepth()));
	}
	}

	}

	
}



